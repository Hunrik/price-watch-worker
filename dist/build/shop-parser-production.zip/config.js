'use strict';

module.exports = {
  concurrency: 10,
  sqsUrl: 'https://sqs.eu-central-1.amazonaws.com/284590800778/Parser'
};